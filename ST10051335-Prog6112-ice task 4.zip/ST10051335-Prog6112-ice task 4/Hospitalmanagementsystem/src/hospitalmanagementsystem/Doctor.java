
package hospitalmanagementsystem;

import java.util.Scanner;

public class Doctor extends HospitalStaff {
    private boolean isSpecialist;
    
    @Override
    public void setData() {
        super.setData();
        Scanner input = new Scanner(System.in);
        System.out.print("Is this doctor a specialist (true/false)? ");
        isSpecialist = input.nextBoolean();
    }
    
    @Override
    public void display() {
        super.display();
        System.out.println("Specialist: " + (isSpecialist ? "Yes" : "No"));
    }
}

