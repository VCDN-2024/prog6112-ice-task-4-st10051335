
package hospitalmanagementsystem;

import java.util.Scanner;

public class HospitalManagement {
    public static void main(String[] args) {
        HospitalStaff[] hospitalStaff = new HospitalStaff[4];
        Doctor[] doctors = new Doctor[3];
        Patient[] patients = new Patient[7];
        
        int staffCount = 0;
        int doctorCount = 0;
        int patientCount = 0;
        
        Scanner input = new Scanner(System.in);
        char choice;
        
        do {
            System.out.print("Enter person type (H for HospitalStaff, D for Doctor, P for Patient, Q to quit): ");
            choice = input.next().charAt(0);
            input.nextLine();  // consume newline

            switch (choice) {
                case 'H':
                    if (staffCount < 4) {
                        hospitalStaff[staffCount] = new HospitalStaff();
                        hospitalStaff[staffCount].setData();
                        staffCount++;
                    } else {
                        System.out.println("Cannot add more HospitalStaff.");
                    }
                    break;
                case 'D':
                    if (doctorCount < 3) {
                        doctors[doctorCount] = new Doctor();
                        doctors[doctorCount].setData();
                        doctorCount++;
                    } else {
                        System.out.println("Cannot add more Doctors.");
                    }
                    break;
                case 'P':
                    if (patientCount < 7) {
                        patients[patientCount] = new Patient();
                        patients[patientCount].setData();
                        patientCount++;
                    } else {
                        System.out.println("Cannot add more Patients.");
                    }
                    break;
                case 'Q':
                    System.out.println("Exiting data entry.");
                    break;
                default:
                    System.out.println("Invalid option.");
            }
        } while (choice != 'Q');
        
        // Display the report
        System.out.println("\nHospital Staff:");
        if (staffCount == 0) {
            System.out.println("No Hospital Staff entered.");
        } else {
            for (int i = 0; i < staffCount; i++) {
                hospitalStaff[i].display();
                System.out.println();
            }
        }
        
        System.out.println("\nDoctors:");
        if (doctorCount == 0) {
            System.out.println("No Doctors entered.");
        } else {
            for (int i = 0; i < doctorCount; i++) {
                doctors[i].display();
                System.out.println();
            }
        }
        
        System.out.println("\nPatients:");
        if (patientCount == 0) {
            System.out.println("No Patients entered.");
        } else {
            for (int i = 0; i < patientCount; i++) {
                patients[i].display();
                System.out.println();
            }
        }
    }
}
