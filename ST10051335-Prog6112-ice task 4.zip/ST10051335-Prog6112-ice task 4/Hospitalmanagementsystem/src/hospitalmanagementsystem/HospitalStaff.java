
package hospitalmanagementsystem;

import java.util.Scanner;

public class HospitalStaff extends Person {
    protected String staffID;
    protected double annualSalary;
    protected String departmentName;
    
    @Override
    public void setData() {
        super.setData();
        Scanner input = new Scanner(System.in);
        System.out.print("Enter Staff ID: ");
        staffID = input.nextLine();
        System.out.print("Enter Annual Salary: ");
        annualSalary = input.nextDouble();
        input.nextLine();  // consume the newline character
        System.out.print("Enter Department Name: ");
        departmentName = input.nextLine();
    }
    
    @Override
    public void display() {
        super.display();
        System.out.println("Staff ID: " + staffID + ", Salary: " + annualSalary + ", Department: " + departmentName);
    }
}

