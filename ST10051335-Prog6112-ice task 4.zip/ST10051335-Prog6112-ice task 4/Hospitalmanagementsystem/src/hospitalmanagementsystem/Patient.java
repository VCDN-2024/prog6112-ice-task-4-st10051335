
package hospitalmanagementsystem;

import java.util.ArrayList;
import java.util.Scanner;

public class Patient extends Person {
    private String medicalRecordNumber;
    private ArrayList<String> ailments;
    
    @Override
    public void setData() {
        super.setData();
        Scanner input = new Scanner(System.in);
        System.out.print("Enter Medical Record Number: ");
        medicalRecordNumber = input.nextLine();
        
        ailments = new ArrayList<>();
        String ailment;
        do {
            System.out.print("Enter Ailment (or 'done' to stop): ");
            ailment = input.nextLine();
            if (!ailment.equalsIgnoreCase("done")) {
                ailments.add(ailment);
            }
        } while (!ailment.equalsIgnoreCase("done"));
    }
    
    @Override
    public void display() {
        super.display();
        System.out.print("Medical Record Number: " + medicalRecordNumber + ", Ailments: ");
        if (ailments.isEmpty()) {
            System.out.println("No ailments.");
        } else {
            System.out.println(String.join(", ", ailments));
        }
    }
}
