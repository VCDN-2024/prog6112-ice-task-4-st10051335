
package hospitalmanagementsystem;

import java.util.Scanner;

public class Person {
    protected String firstName;
    protected String lastName;
    protected String streetAddress;
    protected String zipCode;
    protected String phoneNumber;
    
    public void setData() {
        Scanner input = new Scanner(System.in);
        System.out.print("Enter First Name: ");
        firstName = input.nextLine();
        System.out.print("Enter Last Name: ");
        lastName = input.nextLine();
        System.out.print("Enter Street Address: ");
        streetAddress = input.nextLine();
        System.out.print("Enter Zip Code: ");
        zipCode = input.nextLine();
        System.out.print("Enter Phone Number: ");
        phoneNumber = input.nextLine();
    }
    
    public void display() {
        System.out.println(firstName + " " + lastName + ", " + streetAddress + ", " + zipCode + ", " + phoneNumber);
    }
}

